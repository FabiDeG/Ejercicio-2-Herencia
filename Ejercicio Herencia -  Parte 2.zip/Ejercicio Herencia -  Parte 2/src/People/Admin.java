package People;

public class Admin {

}
