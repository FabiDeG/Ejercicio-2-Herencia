package People;

public class Client {

}
