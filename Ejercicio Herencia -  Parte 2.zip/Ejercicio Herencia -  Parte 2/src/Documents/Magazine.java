package Documents;

public class Magazine {

}
