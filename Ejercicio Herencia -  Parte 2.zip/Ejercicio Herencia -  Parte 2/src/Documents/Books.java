package Documents;

public class Books extends Doc {

	public Books(int[] _ID, String[] _Title, String[] _Author, String[] _Publisher) {
		super();
		this.setAuthor(_Author);
		this.setTitle(_Title);
		this.setPublisher(_Publisher);
	}
	

	
}
