package Documents;

public class Article {

}
