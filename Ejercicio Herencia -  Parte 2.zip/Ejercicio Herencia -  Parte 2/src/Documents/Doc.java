package Documents;

import javax.swing.Spring;

public abstract class Doc {
	
	protected int[] ID;
	protected String[] Title;
	protected String[] Author;
	protected String[] Publisher ;
	protected String[] Topic;
	protected String[] Copy;
	protected String[] Status;
	
	public void SortingAlgorithm(int[] _ID) {
		this.setID(_ID);
	}
	
	public int[] getID() {
		return ID;
	}
	
	public void setID(int[] ID) {
		this.ID = ID;
	}
	
	public void SortingAlgorithm1(String[] _Title) {
		this.setTitle(_Title);
	}
	
	public String[] getTitle() {
		return Title;
	}
	
	public void setTitle(String[] Title) {
		this.Title = Title;
	}
	
	public void SortingAlgorithm2(String[] _Author) {
		this.setAuthor(_Author);
	}
	
	public String[] getAuthor() {
		return Author;
	}
	
	public void setAuthor(String[] Author) {
		this.Author = Author;
	}
	
	public void SortingAlgorithm3(String[] _Publisher) {
		this.setPublisher(_Publisher);
	}
	
	public String[] getPublisher() {
		return Publisher;
	}
	
	public void setPublisher(String[] Publisher) {
		this.Publisher = Publisher;
	}
	
	public void SortingAlgorithm4(String[] _Topic) {
		this.setTopic(_Topic);
	}
	
	public String[] getTopic() {
		return Topic;
	}
	
	public void setTopic(String[] Topic) {
		this.Topic = Topic;
	}
	
	
}
